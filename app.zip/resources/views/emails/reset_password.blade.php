<html>
    <head>
        <title>Password Reset Successfully!</title>
    </head>
    <body>
        <table>
            <tr><td>Dear User</td></tr>
            <tr><td>&nbsp;</td></tr>
            <tr><td>Your password reset successfully and account activated now.</td></tr>
            <tr><td>You can login now with your new password.</td></tr>
            <tr><td>&nbsp;</td></tr>
            <tr><td><a href="{{ url('/login') }}">Login Now</a></td></tr>
            <tr><td>&nbsp;</td></tr>
            <tr><td>Thanks & Regards,</td></tr>
            <tr><td>India Property Clinic</td></tr>
        </table>
    </body>
</html>