<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-144850048-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());


  gtag('config', 'UA-144850048-1');
</script>
<meta name="yandex-verification" content="374eb36b351f2218" />

<script type='application/ld+json'> 
{
  "@context": "http://www.schema.org",
  "@type": "WebSite",
  "name": "indiapropertyclinic",
  "alternateName": "IPC",
  "url": "https://www.indiapropertyclinic.com/"
}
 </script>