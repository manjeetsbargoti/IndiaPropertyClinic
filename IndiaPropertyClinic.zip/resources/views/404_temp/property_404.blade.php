@extends('layouts.frontLayout.frontend_design')
@section('content')

<h1>There is no Property with this name.</h1>


@endsection